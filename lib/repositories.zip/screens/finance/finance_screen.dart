import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../repositories/finance_transaction_repository.dart';
import '../../screens/finance/finance_category_screen.dart';
import '../../screens/finance/finance_transaction_form_screen.dart';
import '../../screens/finance/finance_report_screen.dart';

class FinanceScreen extends StatefulWidget {
  const FinanceScreen({Key? key}) : super(key: key);

  @override
  _FinanceScreenState createState() => _FinanceScreenState();
}

class _FinanceScreenState extends State<FinanceScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final FinanceTransactionRepository _transactionRepository = FinanceTransactionRepository();
  bool _isLoading = true;
  Map<String, int> _summary = {'income': 0, 'expense': 0, 'profit': 0};

  // Filter date range
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 30));
  DateTime _endDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadSummary();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadSummary() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final startDateStr = DateFormat('yyyy-MM-dd').format(_startDate);
      final endDateStr = DateFormat('yyyy-MM-dd').format(_endDate);

      final summary = await _transactionRepository.getSummary(startDateStr, endDateStr);

      setState(() {
        _summary = summary;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showErrorSnackBar('Gagal memuat ringkasan keuangan');
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  Future<void> _selectDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: Colors.blue.shade700,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
      _loadSummary();
    }
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp',
      decimalDigits: 0,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Keuangan'),
        actions: [
          IconButton(
            icon: const Icon(Icons.date_range),
            onPressed: _selectDateRange,
            tooltip: 'Pilih Rentang Tanggal',
          ),
          IconButton(
            icon: const Icon(Icons.category),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const FinanceCategoryScreen(),
                ),
              );
            },
            tooltip: 'Kategori',
          ),
          IconButton(
            icon: const Icon(Icons.bar_chart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => FinanceReportScreen(
                    startDate: _startDate,
                    endDate: _endDate,
                  ),
                ),
              ).then((_) => _loadSummary());
            },
            tooltip: 'Laporan',
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Pemasukan'),
            Tab(text: 'Pengeluaran'),
          ],
        ),
      ),
      body: Column(
        children: [
          // Summary section
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.grey.shade100,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Ringkasan Keuangan',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade800,
                      ),
                    ),
                    Text(
                      '${DateFormat('d MMM').format(_startDate)} - ${DateFormat('d MMM yyyy').format(_endDate)}',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : Row(
                  children: [
                    Expanded(
                      child: _buildSummaryCard(
                        'Pemasukan',
                        currencyFormat.format(_summary['income'] ?? 0),
                        Colors.green,
                        Icons.arrow_downward,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildSummaryCard(
                        'Pengeluaran',
                        currencyFormat.format(_summary['expense'] ?? 0),
                        Colors.red,
                        Icons.arrow_upward,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildSummaryCard(
                        'Laba Bersih',
                        currencyFormat.format(_summary['profit'] ?? 0),
                        Colors.blue,
                        Icons.account_balance_wallet,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Transactions list
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // Income tab
                FinanceTransactionListTab(
                  type: 'income',
                  startDate: _startDate,
                  endDate: _endDate,
                  onTransactionChanged: _loadSummary,
                ),

                // Expense tab
                FinanceTransactionListTab(
                  type: 'expense',
                  startDate: _startDate,
                  endDate: _endDate,
                  onTransactionChanged: _loadSummary,
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FinanceTransactionFormScreen(
                type: _tabController.index == 0 ? 'income' : 'expense',
              ),
            ),
          ).then((_) => _loadSummary());
        },
        backgroundColor: _tabController.index == 0 ? Colors.green : Colors.red,
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
        tooltip: 'Tambah Transaksi',
      ),
    );
  }

  Widget _buildSummaryCard(String title, String value, Color color, IconData icon) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 16),
                const SizedBox(width: 4),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: color,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class FinanceTransactionListTab extends StatefulWidget {
  final String type;
  final DateTime startDate;
  final DateTime endDate;
  final VoidCallback onTransactionChanged;

  const FinanceTransactionListTab({
    Key? key,
    required this.type,
    required this.startDate,
    required this.endDate,
    required this.onTransactionChanged,
  }) : super(key: key);

  @override
  _FinanceTransactionListTabState createState() => _FinanceTransactionListTabState();
}

class _FinanceTransactionListTabState extends State<FinanceTransactionListTab> with AutomaticKeepAliveClientMixin {
  final FinanceTransactionRepository _transactionRepository = FinanceTransactionRepository();
  List<dynamic> _transactions = [];
  bool _isLoading = true;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadTransactions();
  }

  @override
  void didUpdateWidget(FinanceTransactionListTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.startDate != widget.startDate || oldWidget.endDate != widget.endDate) {
      _loadTransactions();
    }
  }

  Future<void> _loadTransactions() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final startDateStr = DateFormat('yyyy-MM-dd').format(widget.startDate);
      final endDateStr = DateFormat('yyyy-MM-dd').format(widget.endDate);

      final transactions = await _transactionRepository.getTransactionsByType(widget.type);

      // Filter by date range
      final filteredTransactions = transactions.where((tx) {
        final txDate = DateTime.parse(tx.date);
        return txDate.isAfter(widget.startDate.subtract(const Duration(days: 1))) &&
            txDate.isBefore(widget.endDate.add(const Duration(days: 1)));
      }).toList();

      setState(() {
        _transactions = filteredTransactions;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showErrorSnackBar('Gagal memuat transaksi');
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  Future<void> _deleteTransaction(int id) async {
    try {
      await _transactionRepository.deleteTransaction(id);
      _loadTransactions();
      widget.onTransactionChanged();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Transaksi berhasil dihapus')),
        );
      }
    } catch (e) {
      if (mounted) {
        _showErrorSnackBar('Gagal menghapus transaksi');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final currencyFormat = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp',
      decimalDigits: 0,
    );

    return RefreshIndicator(
      onRefresh: () async {
        await _loadTransactions();
        widget.onTransactionChanged();
      },
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _transactions.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              widget.type == 'income' ? Icons.arrow_downward : Icons.arrow_upward,
              size: 80,
              color: Colors.grey.shade300,
            ),
            const SizedBox(height: 16),
            Text(
              widget.type == 'income'
                  ? 'Belum ada data pemasukan'
                  : 'Belum ada data pengeluaran',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => FinanceTransactionFormScreen(
                      type: widget.type,
                    ),
                  ),
                ).then((_) {
                  _loadTransactions();
                  widget.onTransactionChanged();
                });
              },
              icon: const Icon(Icons.add),
              label: Text(
                widget.type == 'income'
                    ? 'Tambah Pemasukan'
                    : 'Tambah Pengeluaran',
              ),
            ),
          ],
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _transactions.length,
        itemBuilder: (context, index) {
          final transaction = _transactions[index];
          final transactionDate = DateTime.parse(transaction.date);
          final formattedDate = DateFormat('dd MMM yyyy').format(transactionDate);

          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
              leading: CircleAvatar(
                backgroundColor: widget.type == 'income'
                    ? Colors.green.shade100
                    : Colors.red.shade100,
                child: Icon(
                  widget.type == 'income'
                      ? Icons.arrow_downward
                      : Icons.arrow_upward,
                  color: widget.type == 'income'
                      ? Colors.green
                      : Colors.red,
                ),
              ),
              title: Text(
                transaction.categoryName ?? 'Kategori Tidak Diketahui',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(formattedDate),
                  if (transaction.description != null && transaction.description!.isNotEmpty)
                    Text(
                      transaction.description!,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                ],
              ),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    currencyFormat.format(transaction.amount),
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: widget.type == 'income'
                          ? Colors.green
                          : Colors.red,
                    ),
                  ),
                  Text(
                    transaction.paymentMethod?.toUpperCase() ?? 'TUNAI',
                    style: TextStyle(
                      fontSize: 10,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => FinanceTransactionFormScreen(
                      type: widget.type,
                      transaction: transaction,
                    ),
                  ),
                ).then((_) {
                  _loadTransactions();
                  widget.onTransactionChanged();
                });
              },
              onLongPress: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Hapus Transaksi'),
                    content: const Text(
                      'Apakah Anda yakin ingin menghapus transaksi ini?',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Batal'),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                          _deleteTransaction(transaction.id!);
                        },
                        child: const Text(
                          'Hapus',
                          style: TextStyle(color: Colors.red),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
